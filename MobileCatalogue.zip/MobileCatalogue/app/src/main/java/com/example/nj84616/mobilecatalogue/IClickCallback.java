package com.example.nj84616.mobilecatalogue;

public interface IClickCallback {

    void OnItemClick(int position);

}

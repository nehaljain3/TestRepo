package com.example.nj84616.mobilecatalogue.home;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;

public class MobileCatalogUtils {
    public static String loadMVPJSONFromAsset(Context mContext) {
        String json;
        try {
            InputStream is;
            is = mContext.getAssets().open("mvp.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            //noinspection ResultOfMethodCallIgnored
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

    public static String loadJSONFromAsset(Context mContext,int position) {
        String json;
        try {
            InputStream is = null;
            switch (position){
                case 0:
                    is = mContext.getAssets().open("borrow.json");
                    break;
                case 1:
                    is = mContext.getAssets().open("invest.json");
                    break;
                case 2:
                    is = mContext.getAssets().open("information.json");
                    break;
                case 3:
                    is = mContext.getAssets().open("pay.json");
                    break;
                case 4:
                    is = mContext.getAssets().open("identify.json");
                    break;
                case 5:
                    is = mContext.getAssets().open("enable.json");
                    break;
            }

            int size = is.available();
            byte[] buffer = new byte[size];
            //noinspection ResultOfMethodCallIgnored
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");
        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;
    }

}

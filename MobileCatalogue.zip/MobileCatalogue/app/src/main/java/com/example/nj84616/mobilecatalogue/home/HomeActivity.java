package com.example.nj84616.mobilecatalogue.home;

import android.os.Build;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Window;


import com.example.nj84616.mobilecatalogue.R;
import com.example.nj84616.mobilecatalogue.adapter.HomeAdapter;
import com.example.nj84616.mobilecatalogue.model.MVP;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class HomeActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private static ArrayList<MVP> data;
    private static RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    private Toolbar mTopToolbar;


    public HomeActivity() throws JSONException {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home_activity);

        mTopToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mTopToolbar);



        recyclerView = findViewById(R.id.rv_dashboard);
        layoutManager = new GridLayoutManager(this, 2);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());

        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            window.setStatusBarColor(ContextCompat.getColor(getApplicationContext(),R.color.white));
        }

        try {
            loadfromJSON();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    /**
     * In the below code snippet we are loading the symptoms_details.json JSON file from assets.
     * and setting adapter {@link HomeAdapter} to allSymptomsListView
     */
    private void loadfromJSON() throws JSONException {

        data = new ArrayList<>();
        loadDataFromJson(new JSONObject(MobileCatalogUtils.loadMVPJSONFromAsset(HomeActivity.this)));

        adapter = new HomeAdapter(this, data);

        recyclerView.setAdapter(adapter);
    }


    private void loadDataFromJson(JSONObject aJsonObject) {
        JSONArray jsonArray = new JSONArray();
        try {
            jsonArray = aJsonObject.getJSONArray("MVP");
        } catch (JSONException e) {
            e.printStackTrace();
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            MVP mvp = new MVP();
            try {
                mvp.setBackgroundColor(jsonArray.getJSONObject(i).getString
                        ("backgroundColor"));
                mvp.setForegroundColor(jsonArray.getJSONObject(i).
                        getString("foregroundColor"));
                mvp.setFtrBGColor(jsonArray.getJSONObject(i).getString
                        ("ftrBGColor"));
                mvp.setFtrFGColor(jsonArray.getJSONObject(i).getString("ftrFGColor"));
                mvp.setIcon(jsonArray.getJSONObject(i).getString("icon"));
                mvp.setTitle(jsonArray.getJSONObject(i).getString("title"));

                data.add(mvp);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }



}
